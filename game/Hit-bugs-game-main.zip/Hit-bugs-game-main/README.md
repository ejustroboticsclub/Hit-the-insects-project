# Hit-bugs-game
What is the game where you smash bugs? Bugs Smasher - Protect houses on the App Store Bugs Smasher is a fun game in its purest form. No hard rules to comprehend. Just one goal: have fun smashing up as many insects as possible.
