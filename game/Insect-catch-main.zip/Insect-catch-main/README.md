# Insect-catch

## Interesting insect catch up (or kill) game where you've to hit the insect and your score counts !
## You've the option to select which insect you wanna choose.

### But the frequency of insects on the screen increases too as soon as you start killing them !!



![2022-05-24 19_29_09-Greenshot](https://user-images.githubusercontent.com/71679521/170463684-6eb4a004-457e-4a15-bf7f-cb44fe971ce8.png)

![2022-05-24 19_29_16-Greenshot](https://user-images.githubusercontent.com/71679521/170463689-d1250669-5f02-4c17-bd0a-022f03753687.png)

![2022-05-24 19_29_30-Greenshot](https://user-images.githubusercontent.com/71679521/170463700-68b9d2eb-e3f6-439e-b38f-ca98ad8b40e5.png)

